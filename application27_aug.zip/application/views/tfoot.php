<tfoot >
                                       
                                       <tr class="anuj">
                                           <th>Sr.no</th>
                                           <th>Machine Number</th>
                                           <th>Machine Description</th>
                                           <th>1<sup>St</sup> Monthly</th>
                                           <th>3<sup>rd</sup> Monthly</th>
                                           <th>4<sup>Th</sup> Monthly</th>
                                           <th>6<sup>Th</sup> Monthly</th>
                                           <th>8<sup>Th</sup> Monthly</th>
                                           <th>9<sup>Th</sup> Monthly</th>
                                           <th>12<sup>Th</sup> Monthly</th>
                                           <th>Maintaince Count (Month/Year) </th>
                                           <th>Maintaince Count (Month/Year)</th>
                                           <!-- <th>Actions</th> -->
                                          
                                       </tr>
                                       <tr id="anuj" class="anuj">
                                           <th class="text-center" colspan="3"></th>
                                          
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           <th>
                                            <div class="row">
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-danger text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                                <div class="col-lg-6">
                                                                <span class="text-white">.</span>

                                                                </div>
                                                                <div class="col-lg-6">

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block" class="btn btn-warning text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <button style="display:inline-block;background-color:orange" class="btn  text-white">  <?php echo $danger_count_1;?></button> <br>

                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>
                                            <!-- <br>
                                            <button style="display:inline-block" class="btn btn-success text-white">  <?php echo $danger_count_1;?></button> <br> -->
                                           
                                           
                                           
                                           </th>
                                           
                                          
                                           <th></th>
                                           <th></th>

                                          
                                           <!-- <th>Actions</th> -->
                                          
                                       </tr>
                                   </tfoot>