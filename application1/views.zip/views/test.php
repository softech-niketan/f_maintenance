$yellow_count_1 = 0;
                                            $yellow_count_3 = 0;
                                            $yellow_count_4 = 0;
                                            $yellow_count_6 = 0;
                                            $yellow_count_8 = 0;
                                            $yellow_count_9 = 0;
                                            $yellow_count_12 = 0;